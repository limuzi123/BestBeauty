package com.lanou3g.mostbeauty.activity;

/**
 * Created by dllo on 16/8/30.
 */
public class API {
    public static String PICTORIAL_FRAGMENT = "http://design.zuimeia.com/api/v1/articles/daily/simple/?page=1&page_size=30&user_id=0&device_id=865813020717575&platform=android&lang=zh&appVersion=1.1.7_1&appVersionCode=10171&systemVersion=19&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
    public static String Have_Things_Have_Adapter = "http://design.zuimeia.com/api/v1/activities/daily/?timestamp=";
    public static String HAVE_THINGS_FRAGMENT = "http://design.zuimeia.com/api/v1/product/categories/?device_id=000000000000000&platform=android&lang=zh&appVersion=1.1.7_1&appVersionCode=10171&systemVersion=19&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
    public static String PICTORIAL_ACTIVITY_WEBVIEW = "http://design.zuimeia.com/article/";
    public static String PICTORIAL_ACTIVITY_WEBVIEW_TWO = "/";
    public static String PICTORIAL_ACTIVITY_ONE = "http://design.zuimeia.com/api/v1/article/";
    public static String PICTORIAL_ACTIVITY_TWO = "/?device_id=000000000000000&platform=android&lang=zh&appVersion=1.1.7_1&appVersionCode=10171&systemVersion=19&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
    public static String PICTORIAL_AUTHOR_ACTYVITY_VIEWPAGER_TOP_ONE = "http://design.zuimeia.com/api/v1/designer/";
    public static String STYLIST_FRAGMNET = "http://design.zuimeia.com/api/v1/designers/?page=1&page_size=30&device_id=000000000000000&platform=android&lang=zh&appVersion=1.1.8_2&appVersionCode=10182&systemVersion=22&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
    public static String PICTORIAL_AUTHOR_ACTYVITY_VIEWPAGER_TOP_TWO = "/?device_id=000000000000000&platform=android&lang=zh&appVersion=1.1.8_2&appVersionCode=10182&systemVersion=22&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
    public static String PICYOR_COMMENT_ACTIVITY_ONE = "http://design.zuimeia.com/api/v1/comments/article/";
<<<<<<< HEAD
    public static  String PICTORIAL_STORE_FRAGMENT_ONE ="http://design.zuimeia.com/api/v1/shops/designer/";
public static String PICTORIAL_STORE_FRAGMENT_TWO ="/?device_id=000000000000000&platform=android&lang=zh&appVersion=1.1.8_2&appVersionCode=10182&systemVersion=22&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
public static String READER_ACTIVITY_ONE ="http://design.zuimeia.com/api/v1/user/";
public static String  READER_ACTIVITY_TWO="/?device_id=000000000000000&platform=android&lang=zh&appVersion=1.1.8_2&appVersionCode=10182&systemVersion=22&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
=======

>>>>>>> 80326f4f49bf17c33e59ac3ac859738fa8a9ce50
    public static String PICYOR_COMMENT_ACTIVITY_TWO = "/?page=1&page_size=30&device_id=000000000000000&platform=android&lang=zh&appVersion=1.1.8_2&appVersionCode=10182&systemVersion=22&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
    public static String Have_Things_Have_Adapter_End = "&device_id=000000000000000&platform=android&lang=zh&appVersion=1.1.7_1&appVersionCode=10171&systemVersion=19&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
}
