package com.lanou3g.mostbeauty.myview;

import android.content.Context;
import android.widget.ScrollView;

/**
 * Created by dllo on 16/9/2.
 */
public class MyScrollView extends ScrollView{
    public MyScrollView(Context context) {
        super(context);
    }
}
