package com.lanou3g.mostbeauty.Bean;

import java.util.List;

/**
 * Created by dllo on 16/8/31.
 */
public class HaveThingsHaveBean {

    /**
     * has_next : 1
     * activities : [{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/643c4b64-d9e7-4b94-9ffa-600ee03539aa_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/a4027bac-db0d-4928-abe0-6cfd6bc2add7_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/0b4ef261-fdd6-457e-9626-13b0da8d79f4_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/a49f8b5d-522b-405c-a433-d82ce170bb81_800x799.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/eedbacae-75c8-4033-9498-bc2b7ddbaafe_800x800.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":115,"like_user_num":769,"id":1033,"name":"Kertis | 蔓草手拿包"},"designer":{"city":"纽约","concept":"最让我激动的是时刻就是想法变成了触手可及的实体","name":"Jessica Kertis Ulrich ","label":"Kertis 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/16/9a33d81b-2391-4225-bee3-0a0f42b68f78.jpg","id":74},"digest":"Kertis | 蔓草手拿包\r\n森系女神心头好"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/1f5280ea-47c6-469f-a414-f405edc38951_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/aab0e37a-fd57-4fa2-9dcc-0a8bcbdb9fc9_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/31023f75-12a7-4022-885b-eceb72c81ea5_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":213,"like_user_num":497,"id":874,"name":"Favor | 弧链耳环"},"designer":{"city":"波特兰","concept":"现代的设计和良心的制造是我工作的核心","name":"Monika Reed","label":"Favor 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/7/22/8a5dc597-1ab8-4326-8a05-479a1a294b52.jpg","id":60},"digest":"Favor | 弧链耳环\r\n耳畔跃动的金色旋律"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/621f5e02-6c04-4acb-9a4d-6b1ea8664526_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/784382c4-05c6-4684-ac99-496a30a05725_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/4088e1e3-25c1-4cf9-ac17-cbdf129a4d5d_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/b4750a69-8fa1-4adc-9b9b-776ee452222d_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/d5413798-e71a-4c9a-8fb6-789aae8b5b03_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":233,"like_user_num":388,"id":1035,"name":"Wood & Faulk | 冒险家周末旅行包"},"designer":{"city":"波特兰","concept":"我喜欢把材料用在出其不意的地方","name":"Matt Pierce","label":"Wood & Faulk 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/18/882c923a-25f8-4dd7-b4ed-c6f53690382c.jpg","id":100},"digest":"Wood & Faulk | 冒险家周末旅行包\r\n带我一起去冒险~"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/2a626dae-c391-475f-b539-6637bdf1e440_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/dca7a0e0-aee5-40a3-97be-280fcc163c08_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/ce1d029c-1038-40d4-80c4-bd43340de745_892x892.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/52e626ca-d22d-4588-b4eb-9386773678be_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":167,"like_user_num":527,"id":1036,"name":"Selin Kent | 'Elena' 钻石项链"},"designer":{"city":"纽约","concept":"珠宝是文化的产物，它对不同地方的人有不同的含义","name":"Selin Kent","label":"Selin Kent 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/19/0f894918-bac9-4f76-aa5a-9f5960149902.jpg","id":77},"digest":"Selin Kent | 'Elena' 钻石项链\r\n纤柔的外表，强大的心"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/ef01826e-2871-450a-985c-6d74e6497ebf_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/e3daa6d5-6b5e-4947-a9dc-2dd050e1f1f6_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/b53a9c23-e8d6-4d3f-8b3e-fb0020b7b636_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":204,"like_user_num":404,"id":1030,"name":"Smoke X Mirrors | 'Money' 金色墨镜"},"designer":{"city":"西雅图","concept":"任何东西都是有灵魂的","name":"David Shabtai","label":"Smoke x Mirrors 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/7/24/a57f37f0-57d1-4da4-a296-c761146f2d32.jpg","id":63},"digest":"Smoke X Mirrors | 'Money' 金色墨镜\r\n墨镜界的土豪金"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/162dee39-43cf-4a8c-bae9-7a94f8733424_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/9c34bf69-717b-4940-a8a4-c8f4052a7bbb_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/7dc9d810-a1e5-428f-ac14-9ee92a1afadc_900x900.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/1bf78109-ebe3-413e-94af-af4bdc79c5e2_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/c1e13112-40c5-4c64-8eea-245d5932f286_800x800.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":146,"like_user_num":562,"id":1029,"name":"Mei-Li Rose | 双泪滴戒指"},"designer":{"city":"伦敦","concept":"我的每件作品之间都是相互传承的","name":"Mei-Li Rose ","label":"Mei-Li Rose 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/5/f71befee-eab8-4e18-b582-7e9b62fd112b.jpg","id":66},"digest":"Mei-Li Rose | 双泪滴戒指\r\n情人的泪滴"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/4e39d3c2-3d1d-4295-a033-304a01c30e12_800x799.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/f710da32-5bdf-4798-9050-7399e3b581d2_862x863.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/96c36824-32d2-411d-b2ab-2c07d2fb107c_898x898.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":365,"like_user_num":202,"id":1031,"name":"The Palatines | 'Satis' 方跟凉鞋"},"designer":{"city":"洛杉矶","concept":"我是艺术家，而不是设计师","name":"Jessica Taft Langdon","label":"The Palatines 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/6/e6abb9f9-4ad3-4aa7-82c9-c453ffdafb5e.jpg","id":43},"digest":"The Palatines | 'Satis' 方跟凉鞋\r\n日光亲吻过的肌肤"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/5979eed7-a816-4de5-9099-22e3163e1b53_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/b4fe51f4-7c2c-4b47-a508-3004f7234e9c_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/14bc9023-4658-4aee-932b-89ed1b4d5e2d_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/7b48e50c-a15f-4078-b7d1-88f4cd694b79_750x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":409,"like_user_num":118,"id":1034,"name":"Kenzo | 虎纹迷你手提包"},"designer":{"city":"纽约","concept":"请和衣服愉快的玩耍，Kenzo就应该有趣好玩。","name":"Carol Lim & Humberto Leon","label":"Kenzo 创意总监","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/22/3a68f9a2-5299-4041-8d08-9c1666df7477.jpg","id":92},"digest":"Kenzo | 虎纹迷你手提包\r\n经久不衰的机车包"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/bb3f4f60-4ade-4344-ba67-e7148b8ec680_900x900.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/59d0ae89-64b5-4baa-a59b-3f8295ef192a_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":129,"like_user_num":563,"id":1032,"name":"Renee Frances | 灵翼项链"},"designer":{"city":"纽约","concept":"旅行是灵感的来源和一次发现有趣材料的机会","name":"Renee Kopec","label":"Renee Frances 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/16/85e19ba0-07b8-4dda-89a2-97db6af095dd.jpg","id":59},"digest":"Renee Frances | 灵翼项链\r\n灵能之翼，神圣守护"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/a18cfbdb-97f9-401c-a05e-bedcae8964fd_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/95bec3d8-913c-4a4f-9435-018e8ba71922_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":275,"like_user_num":393,"id":433,"name":"Barbara Campbell | 月亮之上手镯"},"designer":{"city":"","concept":"穿戴我们首饰的女人，会是时尚的引领者而非跟随者","name":"Barbara Campbell","label":"Barbara Campbell Accessories 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/6/17/2a0d1dcd-fcf4-493f-9119-f464031c7545.jpg","id":33},"digest":" Barbara Campbell | 月亮之上手镯\r\n深幽墨月笼红纱，娇羞风姿秀苍穹"}]
     */

    private DataBean data;
    /**
     * data : {"has_next":1,"activities":[{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/643c4b64-d9e7-4b94-9ffa-600ee03539aa_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/a4027bac-db0d-4928-abe0-6cfd6bc2add7_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/0b4ef261-fdd6-457e-9626-13b0da8d79f4_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/a49f8b5d-522b-405c-a433-d82ce170bb81_800x799.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/eedbacae-75c8-4033-9498-bc2b7ddbaafe_800x800.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":115,"like_user_num":769,"id":1033,"name":"Kertis | 蔓草手拿包"},"designer":{"city":"纽约","concept":"最让我激动的是时刻就是想法变成了触手可及的实体","name":"Jessica Kertis Ulrich ","label":"Kertis 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/16/9a33d81b-2391-4225-bee3-0a0f42b68f78.jpg","id":74},"digest":"Kertis | 蔓草手拿包\r\n森系女神心头好"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/1f5280ea-47c6-469f-a414-f405edc38951_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/aab0e37a-fd57-4fa2-9dcc-0a8bcbdb9fc9_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/31023f75-12a7-4022-885b-eceb72c81ea5_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":213,"like_user_num":497,"id":874,"name":"Favor | 弧链耳环"},"designer":{"city":"波特兰","concept":"现代的设计和良心的制造是我工作的核心","name":"Monika Reed","label":"Favor 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/7/22/8a5dc597-1ab8-4326-8a05-479a1a294b52.jpg","id":60},"digest":"Favor | 弧链耳环\r\n耳畔跃动的金色旋律"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/621f5e02-6c04-4acb-9a4d-6b1ea8664526_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/784382c4-05c6-4684-ac99-496a30a05725_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/4088e1e3-25c1-4cf9-ac17-cbdf129a4d5d_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/b4750a69-8fa1-4adc-9b9b-776ee452222d_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/d5413798-e71a-4c9a-8fb6-789aae8b5b03_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":233,"like_user_num":388,"id":1035,"name":"Wood & Faulk | 冒险家周末旅行包"},"designer":{"city":"波特兰","concept":"我喜欢把材料用在出其不意的地方","name":"Matt Pierce","label":"Wood & Faulk 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/18/882c923a-25f8-4dd7-b4ed-c6f53690382c.jpg","id":100},"digest":"Wood & Faulk | 冒险家周末旅行包\r\n带我一起去冒险~"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/2a626dae-c391-475f-b539-6637bdf1e440_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/dca7a0e0-aee5-40a3-97be-280fcc163c08_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/ce1d029c-1038-40d4-80c4-bd43340de745_892x892.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/52e626ca-d22d-4588-b4eb-9386773678be_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":167,"like_user_num":527,"id":1036,"name":"Selin Kent | 'Elena' 钻石项链"},"designer":{"city":"纽约","concept":"珠宝是文化的产物，它对不同地方的人有不同的含义","name":"Selin Kent","label":"Selin Kent 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/19/0f894918-bac9-4f76-aa5a-9f5960149902.jpg","id":77},"digest":"Selin Kent | 'Elena' 钻石项链\r\n纤柔的外表，强大的心"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/ef01826e-2871-450a-985c-6d74e6497ebf_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/e3daa6d5-6b5e-4947-a9dc-2dd050e1f1f6_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/b53a9c23-e8d6-4d3f-8b3e-fb0020b7b636_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":204,"like_user_num":404,"id":1030,"name":"Smoke X Mirrors | 'Money' 金色墨镜"},"designer":{"city":"西雅图","concept":"任何东西都是有灵魂的","name":"David Shabtai","label":"Smoke x Mirrors 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/7/24/a57f37f0-57d1-4da4-a296-c761146f2d32.jpg","id":63},"digest":"Smoke X Mirrors | 'Money' 金色墨镜\r\n墨镜界的土豪金"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/162dee39-43cf-4a8c-bae9-7a94f8733424_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/9c34bf69-717b-4940-a8a4-c8f4052a7bbb_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/7dc9d810-a1e5-428f-ac14-9ee92a1afadc_900x900.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/1bf78109-ebe3-413e-94af-af4bdc79c5e2_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/c1e13112-40c5-4c64-8eea-245d5932f286_800x800.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":146,"like_user_num":562,"id":1029,"name":"Mei-Li Rose | 双泪滴戒指"},"designer":{"city":"伦敦","concept":"我的每件作品之间都是相互传承的","name":"Mei-Li Rose ","label":"Mei-Li Rose 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/5/f71befee-eab8-4e18-b582-7e9b62fd112b.jpg","id":66},"digest":"Mei-Li Rose | 双泪滴戒指\r\n情人的泪滴"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/4e39d3c2-3d1d-4295-a033-304a01c30e12_800x799.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/f710da32-5bdf-4798-9050-7399e3b581d2_862x863.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/96c36824-32d2-411d-b2ab-2c07d2fb107c_898x898.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":365,"like_user_num":202,"id":1031,"name":"The Palatines | 'Satis' 方跟凉鞋"},"designer":{"city":"洛杉矶","concept":"我是艺术家，而不是设计师","name":"Jessica Taft Langdon","label":"The Palatines 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/6/e6abb9f9-4ad3-4aa7-82c9-c453ffdafb5e.jpg","id":43},"digest":"The Palatines | 'Satis' 方跟凉鞋\r\n日光亲吻过的肌肤"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/5979eed7-a816-4de5-9099-22e3163e1b53_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/b4fe51f4-7c2c-4b47-a508-3004f7234e9c_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/14bc9023-4658-4aee-932b-89ed1b4d5e2d_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/7b48e50c-a15f-4078-b7d1-88f4cd694b79_750x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":409,"like_user_num":118,"id":1034,"name":"Kenzo | 虎纹迷你手提包"},"designer":{"city":"纽约","concept":"请和衣服愉快的玩耍，Kenzo就应该有趣好玩。","name":"Carol Lim & Humberto Leon","label":"Kenzo 创意总监","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/22/3a68f9a2-5299-4041-8d08-9c1666df7477.jpg","id":92},"digest":"Kenzo | 虎纹迷你手提包\r\n经久不衰的机车包"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/bb3f4f60-4ade-4344-ba67-e7148b8ec680_900x900.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/59d0ae89-64b5-4baa-a59b-3f8295ef192a_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":129,"like_user_num":563,"id":1032,"name":"Renee Frances | 灵翼项链"},"designer":{"city":"纽约","concept":"旅行是灵感的来源和一次发现有趣材料的机会","name":"Renee Kopec","label":"Renee Frances 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/16/85e19ba0-07b8-4dda-89a2-97db6af095dd.jpg","id":59},"digest":"Renee Frances | 灵翼项链\r\n灵能之翼，神圣守护"},{"images":["http://dstatic.zuimeia.com/common/image/2016/8/26/a18cfbdb-97f9-401c-a05e-bedcae8964fd_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/95bec3d8-913c-4a4f-9435-018e8ba71922_1000x1000.jpeg"],"publish_at":1472227200000,"product":{"unlike_user_num":275,"like_user_num":393,"id":433,"name":"Barbara Campbell | 月亮之上手镯"},"designer":{"city":"","concept":"穿戴我们首饰的女人，会是时尚的引领者而非跟随者","name":"Barbara Campbell","label":"Barbara Campbell Accessories 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/6/17/2a0d1dcd-fcf4-493f-9119-f464031c7545.jpg","id":33},"digest":" Barbara Campbell | 月亮之上手镯\r\n深幽墨月笼红纱，娇羞风姿秀苍穹"}]}
     * result : 1
     */

    private int result;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public static class DataBean {
        private int has_next;
        /**
         * images : ["http://dstatic.zuimeia.com/common/image/2016/8/26/643c4b64-d9e7-4b94-9ffa-600ee03539aa_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/a4027bac-db0d-4928-abe0-6cfd6bc2add7_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/0b4ef261-fdd6-457e-9626-13b0da8d79f4_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/a49f8b5d-522b-405c-a433-d82ce170bb81_800x799.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/26/eedbacae-75c8-4033-9498-bc2b7ddbaafe_800x800.jpeg"]
         * publish_at : 1472227200000
         * product : {"unlike_user_num":115,"like_user_num":769,"id":1033,"name":"Kertis | 蔓草手拿包"}
         * designer : {"city":"纽约","concept":"最让我激动的是时刻就是想法变成了触手可及的实体","name":"Jessica Kertis Ulrich ","label":"Kertis 创始人","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/16/9a33d81b-2391-4225-bee3-0a0f42b68f78.jpg","id":74}
         * digest : Kertis | 蔓草手拿包
         森系女神心头好
         */

        private List<ActivitiesBean> activities;

        public int getHas_next() {
            return has_next;
        }

        public void setHas_next(int has_next) {
            this.has_next = has_next;
        }

        public List<ActivitiesBean> getActivities() {
            return activities;
        }

        public void setActivities(List<ActivitiesBean> activities) {
            this.activities = activities;
        }

        public static class ActivitiesBean {
            private long publish_at;
            /**
             * unlike_user_num : 115
             * like_user_num : 769
             * id : 1033
             * name : Kertis | 蔓草手拿包
             */

            private ProductBean product;
            /**
             * city : 纽约
             * concept : 最让我激动的是时刻就是想法变成了触手可及的实体
             * name : Jessica Kertis Ulrich
             * label : Kertis 创始人
             * avatar_url : http://dstatic.zuimeia.com/designer/avatar/2016/8/16/9a33d81b-2391-4225-bee3-0a0f42b68f78.jpg
             * id : 74
             */

            private DesignerBean designer;
            private String digest;
            private List<String> images;

            public long getPublish_at() {
                return publish_at;
            }

            public void setPublish_at(long publish_at) {
                this.publish_at = publish_at;
            }

            public ProductBean getProduct() {
                return product;
            }

            public void setProduct(ProductBean product) {
                this.product = product;
            }

            public DesignerBean getDesigner() {
                return designer;
            }

            public void setDesigner(DesignerBean designer) {
                this.designer = designer;
            }

            public String getDigest() {
                return digest;
            }

            public void setDigest(String digest) {
                this.digest = digest;
            }

            public List<String> getImages() {
                return images;
            }

            public void setImages(List<String> images) {
                this.images = images;
            }

            public static class ProductBean {
                private int unlike_user_num;
                private int like_user_num;
                private int id;
                private String name;

                public int getUnlike_user_num() {
                    return unlike_user_num;
                }

                public void setUnlike_user_num(int unlike_user_num) {
                    this.unlike_user_num = unlike_user_num;
                }

                public int getLike_user_num() {
                    return like_user_num;
                }

                public void setLike_user_num(int like_user_num) {
                    this.like_user_num = like_user_num;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }
            }

            public static class DesignerBean {
                private String city;
                private String concept;
                private String name;
                private String label;
                private String avatar_url;
                private int id;

                public String getCity() {
                    return city;
                }

                public void setCity(String city) {
                    this.city = city;
                }

                public String getConcept() {
                    return concept;
                }

                public void setConcept(String concept) {
                    this.concept = concept;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getLabel() {
                    return label;
                }

                public void setLabel(String label) {
                    this.label = label;
                }

                public String getAvatar_url() {
                    return avatar_url;
                }

                public void setAvatar_url(String avatar_url) {
                    this.avatar_url = avatar_url;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }
            }
        }
    }
}
