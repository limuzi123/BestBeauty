package com.lanou3g.mostbeauty.fragment.collectfragment;

import com.lanou3g.mostbeauty.R;
import com.lanou3g.mostbeauty.base.BaseFragment;

/**
 * Created by dllo on 16/9/2.
 */
public class AssistFragment extends BaseFragment{
    @Override
    protected int initLayout() {
        return R.layout.assist_fragment;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
