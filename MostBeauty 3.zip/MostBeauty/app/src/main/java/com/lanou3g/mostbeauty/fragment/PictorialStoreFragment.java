package com.lanou3g.mostbeauty.fragment;

import android.support.v4.app.Fragment;

import com.lanou3g.mostbeauty.R;
import com.lanou3g.mostbeauty.base.BaseFragment;

/**
 * Created by dllo on 16/9/3.
 */
public class PictorialStoreFragment extends BaseFragment {

    @Override
    protected int initLayout() {
        return R.layout.fragment_pictorial_store;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
