package com.lanou3g.mostbeauty.Bean;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class HaveHaveBean {


   /**
     * unlike_user_num : 48
     * designer : {"city":"纽约","concept":"时尚是有趣味性的，不要拘泥于陈旧。","name":"Jeremy Scott","label":"Moschino 技术总监","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/27/013ec08f-e6c8-406e-a178-36718ada9211.jpg","id":102,"description":"Jeremy Scott出生在堪萨斯城，在密苏里州的农场长大，但是他内心喜爱时尚，后来前往巴黎， 并住在那里。Jeremy从 14 岁开始学法语，通过自身的努力，以及对时尚的嗅觉和天赋在2013年成为 Moschino 的创意总监。Scott用他独特的讽刺、 幽默、 以及深受流行文化影像学启发的设计把意大利时装屋带回到了聚光灯下。到目前为止，Scott在他 Moschino 集合当中重新阐释芭比娃娃、 麦当劳、 可口可乐和疯子曲调的徽标。"}
     * name : Moschino | 彩色鞋印双肩包
     * cover_images : ["http://dstatic.zuimeia.com/common/image/2016/9/4/024b774b-99cd-4155-b225-6c5b1dcd1fef_1100x1100.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/4/1a3f1180-2150-497b-ba85-224373db7b17_1100x1100.jpeg"]
     * refer_products : [{"name":"Moschino | 虎纹小熊方丝巾","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/29/4d04a79e-d724-4953-9b61-da8e269d31f9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/137cf0fb-3ebc-4808-91a3-61a7b43940d8_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/102426a0-b9c8-4526-99f0-10fbe466d3a0_1000x1000.jpeg"],"price":600,"mark_user_num":8,"images":["http://dstatic.zuimeia.com/common/image/2016/8/29/4d04a79e-d724-4953-9b61-da8e269d31f9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/102426a0-b9c8-4526-99f0-10fbe466d3a0_1000x1000.jpeg"],"publish_at":1472486400000,"id":1060},{"name":"Moschino | '购物袋' 手提包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/9/2/d67412c7-c291-4b33-9eb7-5d808cefd903_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/0a6a5cd6-cfc3-4613-a5a0-b2843f99e62b_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/3f3dbbbc-1660-443e-aaea-2d9ff357b82a_1000x1000.jpeg"],"price":5700,"mark_user_num":13,"images":["http://dstatic.zuimeia.com/common/image/2016/9/2/0a6a5cd6-cfc3-4613-a5a0-b2843f99e62b_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/4ae9b83d-febc-4c87-8ed0-bd3fba09c12c_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/3f3dbbbc-1660-443e-aaea-2d9ff357b82a_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/c04dd020-fa49-4602-8d3f-1895a24bc019_1000x1000.jpeg"],"publish_at":1472832000000,"id":1091},{"name":"Moschino | 烟盒双肩包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/31/7a0cba6f-b04b-419f-b24e-c819c8aa2b4e_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/31/d07a87d1-0d75-4016-bd46-1960bc437b6e_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/31/c84037cd-ee8c-4c04-bfdc-e9a5d94a746f_1000x1000.jpeg"],"price":5280,"mark_user_num":12,"images":["http://dstatic.zuimeia.com/common/image/2016/8/31/54a6a5ad-517a-4bcc-8fff-2569a9dcd5cf_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/31/49e39bd5-36d3-4869-a802-4416f691d946_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/31/f05017e0-5f39-468c-902a-f0f4bbb86987_786x1000.jpeg"],"publish_at":1472659200000,"id":1077},{"name":"Moschino | '问号' 珍珠耳环","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/29/0733177e-c18b-44c3-ab12-d330cf19d348_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/26c46ef6-064c-4abd-b5c6-05b9bd0baf1d_1000x1000.jpeg"],"price":2900,"mark_user_num":2,"images":["http://dstatic.zuimeia.com/common/image/2016/8/29/26c46ef6-064c-4abd-b5c6-05b9bd0baf1d_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/a1cad2a8-e484-4298-ac66-c8da343cbb3f_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/2da4925f-bcd0-4591-a7bf-871faf60d6cc_1000x1000.jpeg"],"publish_at":1472486400000,"id":1055},{"name":"Jeremy Scott | 涂鸦印花箱式手提包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/9/3/efdffb61-c44b-40bf-84ce-38a1444d2e0c_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/3/602344cd-8331-409a-a61b-89eab6e729e9_1000x1000.jpeg"],"price":1750,"mark_user_num":1,"images":["http://dstatic.zuimeia.com/common/image/2016/9/3/72f41ba8-e0dc-4236-bfaa-f006e88f42a6_750x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/3/f1924d16-95c8-464d-a109-2152fcc175c3_750x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/3/674e0a7d-cfbd-4367-b0c9-c2cd2c138246_750x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/3/d3d80b5b-4efd-4b97-94b3-7badcf78abf4_750x1000.jpeg"],"publish_at":1472918400000,"id":1106},{"name":"Moschino | 男士绑带高帮板鞋","cover_images":["http://dstatic.zuimeia.com/common/image/2016/9/1/bc9fe1ff-482e-4a62-ac60-342f7aa84583_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/2f8c0512-d1b1-4e5b-a4de-157ceeb162fc_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/de1380b0-e623-4063-bd82-0df58b0a60a4_1000x1000.jpeg"],"price":4100,"mark_user_num":8,"images":["http://dstatic.zuimeia.com/common/image/2016/9/1/1bf1a119-11b6-4ce5-92e9-57fb82392d37_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/8f94d8f7-a5fa-4670-9123-39ab45740ef0_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/2f8c0512-d1b1-4e5b-a4de-157ceeb162fc_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/de1380b0-e623-4063-bd82-0df58b0a60a4_1000x1000.jpeg"],"publish_at":1472745600000,"id":1080},{"name":"Moschino | 机车夹克链条包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/30/16e8109a-8aca-4872-8c0b-9e6c9ec3e576_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/80e37c25-5106-4b51-b54c-e752da42cc66_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/8b9ece5d-35fa-457d-b91a-d0e5308881e9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/6633ac0e-87e4-4b41-8f2b-d92b9635d3ac_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/bdecae59-0b56-40e5-acdf-2619165f340e_800x800.jpeg"],"price":14200,"mark_user_num":13,"images":["http://dstatic.zuimeia.com/common/image/2016/8/30/c51c245e-18bb-4e5d-a71c-14a79b85d9c6_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/4cc5be6a-e01b-441d-9f91-e2e5d97b9794_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/8b9ece5d-35fa-457d-b91a-d0e5308881e9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/dfcd5dbd-6621-4707-b595-adcefebe1ce4_1000x1000.jpeg"],"publish_at":1472572800000,"id":1067},{"name":"Moschino | 骑士夹克托特包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/27/f4b45f3a-a408-4591-b435-fd6ff6c47e2e_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/27/a9d8b004-e6da-4dda-96e1-e5c78370152f_800x800.jpeg"],"price":3950,"mark_user_num":6,"images":["http://dstatic.zuimeia.com/common/image/2016/8/27/23f0663d-37a6-4059-b5b0-00614bd98705_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/27/914c7943-65d7-46bf-a9d9-c24b37140a90_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/27/945c87d1-a29d-4b7f-9cc8-3ad8cec4cd85_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/27/67c5023b-4fd2-4df6-9cc1-4ba1dca0539b_786x1000.jpeg"],"publish_at":1472313600000,"id":1044}]
     * comment_num : 0
     * price : 4830.0
     * comments : []
     * shop_urls : [{"shop_url":"https://www.moschino.com/hk/moschino/backpack_cod45315425bh.html#dept=bgsbckpc","shop_name":"Moschino 官方网店"}]
     * refer_articles : []
     * like_user_num : 64
     * mark_user_num : 4
     * images : ["http://dstatic.zuimeia.com/common/image/2016/9/4/61a4f158-f96c-4d19-9efa-3363bd8ae0b8_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/4/aadc463d-f495-474e-bd4c-b1df7e31427a_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/4/4c1a90b2-6d73-4cad-9a52-950435dbcad9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/4/1551911e-ae6c-4413-ae42-5c21ece5d599_1000x1000.jpeg"]
     * publish_at : 1473004800000
     * id : 1110
     * digest : 运动感十足的轻型合成面料，配上街头涂鸦风格的彩色鞋印，低调的黑色亦难掩自由不羁的个性气息。在这个追求个人风格的时代，不流于俗，无拘无束，也不失为一个好选择。
     * desc : • 尺寸：宽 30 cm / 高 40 cm / 深 20 cm
     • 材质：90% 尼龙 + 10% 腈纶
     • 彩色鞋印印花
     • 黑色尼龙背带
     • 1 个正面拉链隔层
     • 1 个内侧拉链袋
     • 意大利制造
     */

    private DataBean data;
    /**
     * data : {"unlike_user_num":48,"designer":{"city":"纽约","concept":"时尚是有趣味性的，不要拘泥于陈旧。","name":"Jeremy Scott","label":"Moschino 技术总监","avatar_url":"http://dstatic.zuimeia.com/designer/avatar/2016/8/27/013ec08f-e6c8-406e-a178-36718ada9211.jpg","id":102,"description":"Jeremy Scott出生在堪萨斯城，在密苏里州的农场长大，但是他内心喜爱时尚，后来前往巴黎， 并住在那里。Jeremy从 14 岁开始学法语，通过自身的努力，以及对时尚的嗅觉和天赋在2013年成为 Moschino 的创意总监。Scott用他独特的讽刺、 幽默、 以及深受流行文化影像学启发的设计把意大利时装屋带回到了聚光灯下。到目前为止，Scott在他 Moschino 集合当中重新阐释芭比娃娃、 麦当劳、 可口可乐和疯子曲调的徽标。"},"name":"Moschino | 彩色鞋印双肩包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/9/4/024b774b-99cd-4155-b225-6c5b1dcd1fef_1100x1100.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/4/1a3f1180-2150-497b-ba85-224373db7b17_1100x1100.jpeg"],"refer_products":[{"name":"Moschino | 虎纹小熊方丝巾","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/29/4d04a79e-d724-4953-9b61-da8e269d31f9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/137cf0fb-3ebc-4808-91a3-61a7b43940d8_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/102426a0-b9c8-4526-99f0-10fbe466d3a0_1000x1000.jpeg"],"price":600,"mark_user_num":8,"images":["http://dstatic.zuimeia.com/common/image/2016/8/29/4d04a79e-d724-4953-9b61-da8e269d31f9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/102426a0-b9c8-4526-99f0-10fbe466d3a0_1000x1000.jpeg"],"publish_at":1472486400000,"id":1060},{"name":"Moschino | '购物袋' 手提包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/9/2/d67412c7-c291-4b33-9eb7-5d808cefd903_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/0a6a5cd6-cfc3-4613-a5a0-b2843f99e62b_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/3f3dbbbc-1660-443e-aaea-2d9ff357b82a_1000x1000.jpeg"],"price":5700,"mark_user_num":13,"images":["http://dstatic.zuimeia.com/common/image/2016/9/2/0a6a5cd6-cfc3-4613-a5a0-b2843f99e62b_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/4ae9b83d-febc-4c87-8ed0-bd3fba09c12c_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/3f3dbbbc-1660-443e-aaea-2d9ff357b82a_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/2/c04dd020-fa49-4602-8d3f-1895a24bc019_1000x1000.jpeg"],"publish_at":1472832000000,"id":1091},{"name":"Moschino | 烟盒双肩包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/31/7a0cba6f-b04b-419f-b24e-c819c8aa2b4e_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/31/d07a87d1-0d75-4016-bd46-1960bc437b6e_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/31/c84037cd-ee8c-4c04-bfdc-e9a5d94a746f_1000x1000.jpeg"],"price":5280,"mark_user_num":12,"images":["http://dstatic.zuimeia.com/common/image/2016/8/31/54a6a5ad-517a-4bcc-8fff-2569a9dcd5cf_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/31/49e39bd5-36d3-4869-a802-4416f691d946_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/31/f05017e0-5f39-468c-902a-f0f4bbb86987_786x1000.jpeg"],"publish_at":1472659200000,"id":1077},{"name":"Moschino | '问号' 珍珠耳环","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/29/0733177e-c18b-44c3-ab12-d330cf19d348_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/26c46ef6-064c-4abd-b5c6-05b9bd0baf1d_1000x1000.jpeg"],"price":2900,"mark_user_num":2,"images":["http://dstatic.zuimeia.com/common/image/2016/8/29/26c46ef6-064c-4abd-b5c6-05b9bd0baf1d_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/a1cad2a8-e484-4298-ac66-c8da343cbb3f_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/2da4925f-bcd0-4591-a7bf-871faf60d6cc_1000x1000.jpeg"],"publish_at":1472486400000,"id":1055},{"name":"Jeremy Scott | 涂鸦印花箱式手提包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/9/3/efdffb61-c44b-40bf-84ce-38a1444d2e0c_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/3/602344cd-8331-409a-a61b-89eab6e729e9_1000x1000.jpeg"],"price":1750,"mark_user_num":1,"images":["http://dstatic.zuimeia.com/common/image/2016/9/3/72f41ba8-e0dc-4236-bfaa-f006e88f42a6_750x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/3/f1924d16-95c8-464d-a109-2152fcc175c3_750x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/3/674e0a7d-cfbd-4367-b0c9-c2cd2c138246_750x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/3/d3d80b5b-4efd-4b97-94b3-7badcf78abf4_750x1000.jpeg"],"publish_at":1472918400000,"id":1106},{"name":"Moschino | 男士绑带高帮板鞋","cover_images":["http://dstatic.zuimeia.com/common/image/2016/9/1/bc9fe1ff-482e-4a62-ac60-342f7aa84583_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/2f8c0512-d1b1-4e5b-a4de-157ceeb162fc_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/de1380b0-e623-4063-bd82-0df58b0a60a4_1000x1000.jpeg"],"price":4100,"mark_user_num":8,"images":["http://dstatic.zuimeia.com/common/image/2016/9/1/1bf1a119-11b6-4ce5-92e9-57fb82392d37_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/8f94d8f7-a5fa-4670-9123-39ab45740ef0_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/2f8c0512-d1b1-4e5b-a4de-157ceeb162fc_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/1/de1380b0-e623-4063-bd82-0df58b0a60a4_1000x1000.jpeg"],"publish_at":1472745600000,"id":1080},{"name":"Moschino | 机车夹克链条包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/30/16e8109a-8aca-4872-8c0b-9e6c9ec3e576_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/80e37c25-5106-4b51-b54c-e752da42cc66_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/8b9ece5d-35fa-457d-b91a-d0e5308881e9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/6633ac0e-87e4-4b41-8f2b-d92b9635d3ac_800x800.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/bdecae59-0b56-40e5-acdf-2619165f340e_800x800.jpeg"],"price":14200,"mark_user_num":13,"images":["http://dstatic.zuimeia.com/common/image/2016/8/30/c51c245e-18bb-4e5d-a71c-14a79b85d9c6_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/4cc5be6a-e01b-441d-9f91-e2e5d97b9794_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/8b9ece5d-35fa-457d-b91a-d0e5308881e9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/30/dfcd5dbd-6621-4707-b595-adcefebe1ce4_1000x1000.jpeg"],"publish_at":1472572800000,"id":1067},{"name":"Moschino | 骑士夹克托特包","cover_images":["http://dstatic.zuimeia.com/common/image/2016/8/27/f4b45f3a-a408-4591-b435-fd6ff6c47e2e_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/27/a9d8b004-e6da-4dda-96e1-e5c78370152f_800x800.jpeg"],"price":3950,"mark_user_num":6,"images":["http://dstatic.zuimeia.com/common/image/2016/8/27/23f0663d-37a6-4059-b5b0-00614bd98705_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/27/914c7943-65d7-46bf-a9d9-c24b37140a90_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/27/945c87d1-a29d-4b7f-9cc8-3ad8cec4cd85_786x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/27/67c5023b-4fd2-4df6-9cc1-4ba1dca0539b_786x1000.jpeg"],"publish_at":1472313600000,"id":1044}],"comment_num":0,"price":4830,"comments":[],"shop_urls":[{"shop_url":"https://www.moschino.com/hk/moschino/backpack_cod45315425bh.html#dept=bgsbckpc","shop_name":"Moschino 官方网店"}],"refer_articles":[],"like_user_num":64,"mark_user_num":4,"images":["http://dstatic.zuimeia.com/common/image/2016/9/4/61a4f158-f96c-4d19-9efa-3363bd8ae0b8_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/4/aadc463d-f495-474e-bd4c-b1df7e31427a_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/4/4c1a90b2-6d73-4cad-9a52-950435dbcad9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/9/4/1551911e-ae6c-4413-ae42-5c21ece5d599_1000x1000.jpeg"],"publish_at":1473004800000,"id":1110,"digest":"运动感十足的轻型合成面料，配上街头涂鸦风格的彩色鞋印，低调的黑色亦难掩自由不羁的个性气息。在这个追求个人风格的时代，不流于俗，无拘无束，也不失为一个好选择。","desc":"\u2022 尺寸：宽 30 cm / 高 40 cm / 深 20 cm \r\n\u2022 材质：90% 尼龙 + 10% 腈纶\r\n\u2022 彩色鞋印印花\r\n\u2022 黑色尼龙背带\r\n\u2022 1 个正面拉链隔层\r\n\u2022 1 个内侧拉链袋\r\n\u2022 意大利制造"}
     * result : 1
     */

    private int result;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public static class DataBean {
        private int unlike_user_num;
        /**
         * city : 纽约
         * concept : 时尚是有趣味性的，不要拘泥于陈旧。
         * name : Jeremy Scott
         * label : Moschino 技术总监
         * avatar_url : http://dstatic.zuimeia.com/designer/avatar/2016/8/27/013ec08f-e6c8-406e-a178-36718ada9211.jpg
         * id : 102
         * description : Jeremy Scott出生在堪萨斯城，在密苏里州的农场长大，但是他内心喜爱时尚，后来前往巴黎， 并住在那里。Jeremy从 14 岁开始学法语，通过自身的努力，以及对时尚的嗅觉和天赋在2013年成为 Moschino 的创意总监。Scott用他独特的讽刺、 幽默、 以及深受流行文化影像学启发的设计把意大利时装屋带回到了聚光灯下。到目前为止，Scott在他 Moschino 集合当中重新阐释芭比娃娃、 麦当劳、 可口可乐和疯子曲调的徽标。
         */

        private DesignerBean designer;
        private String name;
        private int comment_num;
        private double price;
        private int like_user_num;
        private int mark_user_num;
        private long publish_at;
        private int id;
        private String digest;
        private String desc;
        private List<String> cover_images;
        /**
         * name : Moschino | 虎纹小熊方丝巾
         * cover_images : ["http://dstatic.zuimeia.com/common/image/2016/8/29/4d04a79e-d724-4953-9b61-da8e269d31f9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/137cf0fb-3ebc-4808-91a3-61a7b43940d8_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/102426a0-b9c8-4526-99f0-10fbe466d3a0_1000x1000.jpeg"]
         * price : 600.0
         * mark_user_num : 8
         * images : ["http://dstatic.zuimeia.com/common/image/2016/8/29/4d04a79e-d724-4953-9b61-da8e269d31f9_1000x1000.jpeg","http://dstatic.zuimeia.com/common/image/2016/8/29/102426a0-b9c8-4526-99f0-10fbe466d3a0_1000x1000.jpeg"]
         * publish_at : 1472486400000
         * id : 1060
         */

        private List<ReferProductsBean> refer_products;
        private List<?> comments;
        /**
         * shop_url : https://www.moschino.com/hk/moschino/backpack_cod45315425bh.html#dept=bgsbckpc
         * shop_name : Moschino 官方网店
         */

        private List<ShopUrlsBean> shop_urls;
        private List<?> refer_articles;
        private List<String> images;

        public int getUnlike_user_num() {
            return unlike_user_num;
        }

        public void setUnlike_user_num(int unlike_user_num) {
            this.unlike_user_num = unlike_user_num;
        }

        public DesignerBean getDesigner() {
            return designer;
        }

        public void setDesigner(DesignerBean designer) {
            this.designer = designer;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getComment_num() {
            return comment_num;
        }

        public void setComment_num(int comment_num) {
            this.comment_num = comment_num;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public int getLike_user_num() {
            return like_user_num;
        }

        public void setLike_user_num(int like_user_num) {
            this.like_user_num = like_user_num;
        }

        public int getMark_user_num() {
            return mark_user_num;
        }

        public void setMark_user_num(int mark_user_num) {
            this.mark_user_num = mark_user_num;
        }

        public long getPublish_at() {
            return publish_at;
        }

        public void setPublish_at(long publish_at) {
            this.publish_at = publish_at;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getDigest() {
            return digest;
        }

        public void setDigest(String digest) {
            this.digest = digest;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public List<String> getCover_images() {
            return cover_images;
        }

        public void setCover_images(List<String> cover_images) {
            this.cover_images = cover_images;
        }

        public List<ReferProductsBean> getRefer_products() {
            return refer_products;
        }

        public void setRefer_products(List<ReferProductsBean> refer_products) {
            this.refer_products = refer_products;
        }

        public List<?> getComments() {
            return comments;
        }

        public void setComments(List<?> comments) {
            this.comments = comments;
        }

        public List<ShopUrlsBean> getShop_urls() {
            return shop_urls;
        }

        public void setShop_urls(List<ShopUrlsBean> shop_urls) {
            this.shop_urls = shop_urls;
        }

        public List<?> getRefer_articles() {
            return refer_articles;
        }

        public void setRefer_articles(List<?> refer_articles) {
            this.refer_articles = refer_articles;
        }

        public List<String> getImages() {
            return images;
        }

        public void setImages(List<String> images) {
            this.images = images;
        }

        public static class DesignerBean {
            private String city;
            private String concept;
            private String name;
            private String label;
            private String avatar_url;
            private int id;
            private String description;

            public String getCity() {
                return city;
            }

            public void setCity(String city) {
                this.city = city;
            }

            public String getConcept() {
                return concept;
            }

            public void setConcept(String concept) {
                this.concept = concept;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getLabel() {
                return label;
            }

            public void setLabel(String label) {
                this.label = label;
            }

            public String getAvatar_url() {
                return avatar_url;
            }

            public void setAvatar_url(String avatar_url) {
                this.avatar_url = avatar_url;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }
        }

        public static class ReferProductsBean {
            private String name;
            private double price;
            private int mark_user_num;
            private long publish_at;
            private int id;
            private List<String> cover_images;
            private List<String> images;

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public double getPrice() {
                return price;
            }

            public void setPrice(double price) {
                this.price = price;
            }

            public int getMark_user_num() {
                return mark_user_num;
            }

            public void setMark_user_num(int mark_user_num) {
                this.mark_user_num = mark_user_num;
            }

            public long getPublish_at() {
                return publish_at;
            }

            public void setPublish_at(long publish_at) {
                this.publish_at = publish_at;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public List<String> getCover_images() {
                return cover_images;
            }

            public void setCover_images(List<String> cover_images) {
                this.cover_images = cover_images;
            }

            public List<String> getImages() {
                return images;
            }

            public void setImages(List<String> images) {
                this.images = images;
            }
        }

        public static class ShopUrlsBean {
            private String shop_url;
            private String shop_name;

            public String getShop_url() {
                return shop_url;
            }

            public void setShop_url(String shop_url) {
                this.shop_url = shop_url;
            }

            public String getShop_name() {
                return shop_name;
            }

            public void setShop_name(String shop_name) {
                this.shop_name = shop_name;
            }
        }
    }
}
