package com.lanou3g.mostbeauty.fragment;

import android.view.View;

import com.lanou3g.mostbeauty.R;
import com.lanou3g.mostbeauty.base.BaseFragment;

/**
 * Created by dllo on 16/8/30.
 */

public class StylistFragment extends BaseFragment{

    @Override
    protected int initLayout() {
        return R.layout.fragment_stylist;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
